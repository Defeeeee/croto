from setuptools import setup, find_packages


setup(
    name='croto',
    version='0.8',
    license='MIT',
    author="Defee",
    author_email='fdiaznemeth@example.com',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    url='https://github.com/Defeeeee/croto',
    keywords='compiled language',

)
